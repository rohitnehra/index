<!DOCTYPE html>
<html lang="en">
  <head>

    <!-- head -->
    <meta charset="utf-8">
    <meta name="msapplication-tap-highlight" content="no" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />


    <!-- Stylesheets -->
    <link href='https://fonts.googleapis.com/css?family=Lato:300,400,700,400italic,300italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="owlcarousel/docs/assets/css/docs.theme.min.css">

    <!-- Owl Stylesheets -->

    <link rel="stylesheet" href="owlcarousel/docs/assets/owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/docs/assets/owlcarousel/assets/owl.theme.default.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">


    <!-- Favicons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="owlcarousel/docs/assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="shortcut icon" href="owlcarousel/docs/assets/ico/favicon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Yeah i know js should not be in header. Its required for demos.-->

    <!-- javascript -->
    <script src="owlcarousel/docs/assets/vendors/jquery.min.js"></script>
    <script src="owlcarousel/docs/assets/owlcarousel/owl.carousel.js"></script>
  </head>
  <body>

    <!--  Demos -->
    <section id="demos">
      <div class="row">
        <div class="large-12 columns">
          <div class="owl-carousel owl-theme">
            <div class="item">
              <h4>1</h4>
            </div>
            <div class="item">
              <h4>2</h4>
            </div>
            <div class="item">
              <h4>3</h4>
            </div>
            <div class="item">
              <h4>4</h4>
            </div>
            <div class="item">
              <h4>5</h4>
            </div>
            <div class="item">
              <h4>6</h4>
            </div>
            <div class="item">
              <h4>7</h4>
            </div>
            <div class="item">
              <h4>8</h4>
            </div>
            <div class="item">
              <h4>9</h4>
            </div>
            <div class="item">
              <h4>10</h4>
            </div>
            <div class="item">
              <h4>11</h4>
            </div>
            <div class="item">
              <h4>12</h4>
            </div>
          </div>


          <script src="owlcarousel/docs/assets/vendors/jquery.mousewheel.min.js"></script>
          <script>
            $(document).ready(function() {
              var owl = $('.owl-carousel');
              owl.owlCarousel({
                loop: true,
                nav: true,
                margin: 50,
                responsive: {
                  0: {
                    items: 1
                  },
                  766: {
                    items: 2
                  },
                  990: {
                    items: 3
                  },
                  1200: {
                    items: 3
                  }
                }
              });
              owl.on('mousewheel', '.owl-stage', function(e) {
                if (e.deltaY > 0) {
                  owl.trigger('next.owl');
                } else {
                  owl.trigger('prev.owl');
                }
                e.preventDefault();
              });
            })
          </script>
        </div>
      </div>
    </section>
    <!-- vendors -->
    <script src="owlcarousel/docs/assets/vendors/highlight.js"></script>
    <script src="owlcarousel/docs/assets/js/app.js"></script>
  </body>
</html>
