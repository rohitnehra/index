<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>

  </head>
  <body>
      <div class="text-center choose"><h2><b>CHOOSE YOUR FUTURE</b></h2></div>
      <div class="text-center">
        <h4><b>Ourdunia.com is an extensive search engine for the students, parents<br>
and education industry players who are seeking information</b></h4>
      </div>
<div class="text-center">
  <div class="btn-group">
    <button type="button" class="btn btn-primary">EXAM</button>
    <button type="button" class="btn btn-primary">COURSE</button>
  </div>
</div>

<div class="row">
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="https://upload.wikimedia.org/wikipedia/en/3/3f/Queens_College_Cambridge_chapel_walnut_tree_court_night.jpg" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="https://upload.wikimedia.org/wikipedia/en/3/3f/Queens_College_Cambridge_chapel_walnut_tree_court_night.jpg" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="https://upload.wikimedia.org/wikipedia/en/3/3f/Queens_College_Cambridge_chapel_walnut_tree_court_night.jpg" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="https://upload.wikimedia.org/wikipedia/en/3/3f/Queens_College_Cambridge_chapel_walnut_tree_court_night.jpg" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="https://upload.wikimedia.org/wikipedia/en/3/3f/Queens_College_Cambridge_chapel_walnut_tree_court_night.jpg" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="https://upload.wikimedia.org/wikipedia/en/3/3f/Queens_College_Cambridge_chapel_walnut_tree_court_night.jpg" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="https://upload.wikimedia.org/wikipedia/en/3/3f/Queens_College_Cambridge_chapel_walnut_tree_court_night.jpg" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="https://upload.wikimedia.org/wikipedia/en/3/3f/Queens_College_Cambridge_chapel_walnut_tree_court_night.jpg" alt="...">
    </a>
  </div>
  ...
</div>



  </body>
</html>
