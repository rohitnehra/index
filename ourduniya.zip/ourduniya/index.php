<?php include 'header.php';?>
<?php include 'explore.php';?>
<?php include 'choose.php';?>
