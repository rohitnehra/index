<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="style1.css">
  </head>
  <body>
    <?php include 'header.php';?>
    <div class="container">
    <div class="row">
    <div class="well">
        <h1 class="text-center">Reviews</h1>
        <div class="list-group">
          <a href="#" class="list-group-item">
                <div class="media col-md-2">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="http://placehold.it/350x250" alt="placehold.it/350x250" >
                    </figure>
                </div>
                <div class="col-md-7">
                    <h4 class="list-group-item-heading"> John </h4>
                    <div class="">
                      <span class="badge">MBA</span>
                      <span class="badge">IIM Ahmedabad</span>
                    </div>
                    <p class="list-group-item-text">I wanted to do an MBA to gain holistic knowledge about the business environment and, hence, I appeared for CAT. I prepared for around 4-5 months and devoted around 2 hours daily for the same. I took coaching from TIME, NOIDA and the faculty there helped me a lot in cracking the exam. I had final admission offers from 13 B-schools including all the IIMs, MDI, FMS, IIFT etc. I chose IIMA because of the world-class faculty, pedagogy and the alumni network. The 2 years I spent there have been the be...
                    </p>
                </div>
                <div class="col-md-3 text-center">


                    <div class="stars">
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star-empty"></span>
                    </div>
                    <p> Average 4.5 <small> / </small> 5 </p>
                </div>
          </a>
          <a href="#" class="list-group-item">
                <div class="media col-md-2">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="http://placehold.it/350x250" alt="placehold.it/350x250" >
                    </figure>
                </div>
                <div class="col-md-7">
                    <h4 class="list-group-item-heading"> John </h4>
                    <div class="">
                      <span class="badge">MBA</span>
                      <span class="badge">IIM Ahmedabad</span>
                    </div>
                    <p class="list-group-item-text">I wanted to do an MBA to gain holistic knowledge about the business environment and, hence, I appeared for CAT. I prepared for around 4-5 months and devoted around 2 hours daily for the same. I took coaching from TIME, NOIDA and the faculty there helped me a lot in cracking the exam. I had final admission offers from 13 B-schools including all the IIMs, MDI, FMS, IIFT etc. I chose IIMA because of the world-class faculty, pedagogy and the alumni network. The 2 years I spent there have been the be...
                    </p>
                </div>
                <div class="col-md-3 text-center">


                    <div class="stars">
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star-empty"></span>
                    </div>
                    <p> Average 4.5 <small> / </small> 5 </p>
                </div>
          </a>
          <a href="#" class="list-group-item">
                <div class="media col-md-2">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="http://placehold.it/350x250" alt="placehold.it/350x250" >
                    </figure>
                </div>
                <div class="col-md-7">
                    <h4 class="list-group-item-heading"> John </h4>
                    <div class="">
                      <span class="badge">MBA</span>
                      <span class="badge">IIM Ahmedabad</span>
                    </div>
                    <p class="list-group-item-text">I wanted to do an MBA to gain holistic knowledge about the business environment and, hence, I appeared for CAT. I prepared for around 4-5 months and devoted around 2 hours daily for the same. I took coaching from TIME, NOIDA and the faculty there helped me a lot in cracking the exam. I had final admission offers from 13 B-schools including all the IIMs, MDI, FMS, IIFT etc. I chose IIMA because of the world-class faculty, pedagogy and the alumni network. The 2 years I spent there have been the be...
                    </p>
                </div>
                <div class="col-md-3 text-center">


                    <div class="stars">
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star-empty"></span>
                    </div>
                    <p> Average 4.5 <small> / </small> 5 </p>
                </div>
          </a>
        </div>
        </div>
</div>
</div>
    <?php include 'footer.php';?>
  </body>
</html>
