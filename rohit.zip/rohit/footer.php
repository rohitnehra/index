<footer class="footer-bg">
  <div class="container">
  <h1>Contact Us</h1>
    <div class="row form-border">
        <form class="footer-title">
          <div class="col-md-6 left-footer">
          <h2>Request A Call Back</h2>
          <hr>
          <p>For Admission: For Admission inquiry fill our short feedback form or you can also send us an email and we'll get in touch shortly, or Toll Free Number +91-9555-101<br>For Customer Support : If you have any doubt about Bogomolets National Medical University or how we can support your query, Send us an email and we’ll get in touch shortly, or Contact via Support Forum</p>
          <p>For Admission: For Admission inquiry fill our short feedback form or you can also send us an email and we'll get in touch shortly, or Toll Free Number +91-9555-101</p>
          </div>
      <div class="col-md-6">
        <div class="form-group">
          <input type="text" class="form-control" id="usr" placeholder="Name">
        </div>
        <div class="form-group">
          <input type="email" class="form-control" id="mail" placeholder="Email">
        </div>
        <div class="form-group">
          <input type="text" class="form-control" id="phone" placeholder="Phone">
        </div>
        <div class="form-group">
          <textarea class="form-control" rows="5" id="comment" placeholder="Message"></textarea>
          <p><a href="#"><button class="btn btn-default">Submit</button></a></p>
        </div>
      </div>
  </form>
    </div>
  </div>
</footer>

  <section class="footer-text">
  <div class="container">
  <hr>
  <div class="end-sec">
    <div class="col-md-3 col-sm-3">
      <h4>TOP COLLEGES FOR</h4>
      <p>M.B.A<br>B.TECH/B.E<br>MCA<br>BCA<br>M.TECH<br>MA<br>BA</p>
    </div>

    <div class="col-md-3 col-sm-3">
      <h4>TOP UNIVERSITIES FOR</h4>
      <p>M.B.A<br>B.TECH/B.E<br>MCA<br>BCA<br>M.TECH<br>MA<br>BA</p>
    </div>

    <div class="col-md-3 col-sm-3">
      <h4>TOP EXAMS</h4>
      <p>M.B.A<br>B.TECH/B.E<br>MCA<br>BCA<br>M.TECH<br>MA<br>BA</p>
    </div>

    <div class="col-md-3 col-sm-3">
       <h4>OTHER LINKS</h4>
      <p>M.B.A<br>B.TECH/B.E<br>MCA<br>BCA<br>M.TECH<br>MA<br>BA</p>
    </div>
    </div>
  </div>
</div>
  </section>
  <script>
  $(window).scroll(function() {
    var height = $(window).scrollTop();
    if (height > 100) {
        $('#back2Top').fadeIn();
    } else {
        $('#back2Top').fadeOut();
    }
  });
  $(document).ready(function() {
    $("#back2Top").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

  });
  </script>
  <script>
  $(document).ready(function(){
    $('.owl-bg').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        dots: false,
        responsive:{
            0:{
                items:1
            },
            768:{
                items:3
            }

        }
    })
  });
  </script>
  <script>
    $(function(){
    $(".dropdown").hover(
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                $(this).toggleClass('open');
                $('b', this).toggleClass("caret caret-up");
            },
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
                $(this).toggleClass('open');
                $('b', this).toggleClass("caret caret-up");
            });
    });

  </script>
  <script>
  $(document).ready(function(){
    var owl = $('.owl-carousel');
                  owl.owlCarousel({
                    loop: true,
                    nav: true,
                    margin: 10,
                    autoplay:true,
                    autoplayTimeout:4000,
                    autoplayHoverPause:true,
                    dots: false,
                    responsive: {
                      0: {
                        items: 1
                      },

                    }
                  });
  });
  </script>
  <script>
    $("body").niceScroll();
    $(".nicescroll-box").niceScroll(".wrap",{cursorcolor:"#487d9d"});
  </script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
