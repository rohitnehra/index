<div class="container bottom-space"><!-- Top Courses section-->
  <div class="row">
    <div class="courses-title text-center">
      <h1>TOP COURSES / COLLEGES</h1>
      <hr>
    </div>
      <div class="col-md-4"><!--first sec-->
        <div class="top-courses">
        <h4>JEE MAIN 2018</h4>
        <p>JEE Main is a National level test conducted for B.E./BTech and B.Arch admissions after class 12.</p>
        <div class="below-text clearfix">
        <div class="left-content">
          <a href="#"><p>JEE Main 2018 Answer Key<br>JEE Main Cut Off</p></a>
        </div>
        <div class="right-btn">
          <a href="#"><button class="btn btn-default btn-sm">Read More</button></a>
        </div>
      </div>
    </div>
  </div>
      <div class="col-md-4">
        <div class="top-courses">
        <h4>JEE MAIN 2018</h4>
        <p>JEE Main is a National level test conducted for B.E./BTech and B.Arch admissions after class 12.</p>
        <div class="below-text clearfix">
        <div class="left-content">
          <a href="#"><p>JEE Main 2018 Answer Key<br>JEE Main Cut Off</p></a>
        </div>
        <div class="right-btn">
          <a href="#"><button class="btn btn-default btn-sm">Read More</button></a>
        </div>
      </div>
    </div>
  </div>
      <div class="col-md-4">
        <div class="top-courses">
        <h4>JEE MAIN 2018</h4>
        <p>JEE Main is a National level test conducted for B.E./BTech and B.Arch admissions after class 12.</p>
        <div class="below-text clearfix">
        <div class="left-content">
          <a href="#"><p>JEE Main 2018 Answer Key<br>JEE Main Cut Off</p></a>
        </div>
        <div class="right-btn">
          <a href="#"><button class="btn btn-default btn-sm">Read More</button></a>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-4"><!--second sec-->
        <div class="top-courses">
        <h4>JEE MAIN 2018</h4>
        <p>JEE Main is a National level test conducted for B.E./BTech and B.Arch admissions after class 12.</p>
        <div class="below-text clearfix">
        <div class="left-content">
          <a href="#"><p>JEE Main 2018 Answer Key<br>JEE Main Cut Off</p></a>
        </div>
        <div class="right-btn">
          <a href="#"><button class="btn btn-default btn-sm">Read More</button></a>
        </div>
      </div>
    </div>
  </div>
      <div class="col-md-4">
        <div class="top-courses">
        <h4>JEE MAIN 2018</h4>
        <p>JEE Main is a National level test conducted for B.E./BTech and B.Arch admissions after class 12.</p>
        <div class="below-text clearfix">
        <div class="left-content">
          <a href="#"><p>JEE Main 2018 Answer Key<br>JEE Main Cut Off</p></a>
        </div>
        <div class="right-btn">
          <a href="#"><button class="btn btn-default btn-sm">Read More</button></a>
        </div>
      </div>
    </div>
  </div>
      <div class="col-md-4">
        <div class="top-courses">
        <h4>JEE MAIN 2018</h4>
        <p>JEE Main is a National level test conducted for B.E./BTech and B.Arch admissions after class 12.</p>
        <div class="below-text clearfix">
        <div class="left-content">
          <a href="#"><p>JEE Main 2018 Answer Key<br>JEE Main Cut Off</p></a>
        </div>
        <div class="right-btn">
          <a href="#"><button class="btn btn-default btn-sm">Read More</button></a>
        </div>
      </div>
    </div>
  </div>
  </div><!-- row-->
</div><!--container-->
