<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>
<section>
<div class="container footer">
  <div class="row">
    <div class="col-sm-4 logo">
      <div class="">
        <img src="logo.png" alt="" class="img-responsive">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
    </div>
    <div class="col-sm-4 mfooter clearfix">
      <h4>Quick view</h4>
      <ul>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>
        <li><a href="#"> <span class="glyphicon glyphicon-chevron-right"></span>  Home </a></li>

      </ul>
    </div>
    <div class="col-sm-4 rfooter">
      <h4>Contact Us</h4>
      <ul>
        <li> <span class="glyphicon glyphicon-envelope"></span> Tarasa Shevchenko Blvd, 13, Kyiv, Ukraine, 01601</li>
        <li> <span class="glyphicon glyphicon-tags"></span> 380686637837</li>
        <li> <span class="glyphicon glyphicon-bookmark"></span>  info@vinnitsa-nmu.com</li>
      </ul>
    </div>
  </div>
</div>







</section>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </body>
</html>
