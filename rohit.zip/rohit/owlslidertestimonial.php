<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>
    </title>
    <link rel="stylesheet" type="text/css" href="owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="owl.theme.default.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="owlstyle.css">
    <script src="jquery.min.js"></script>
    <script src="owl.carousel.min.js"></script>

  </head>
  <body>
    <div class="owl-carousel owl-theme testimo">
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>
        <div class="item">
          <div class="text-center testimondiv">
            <h1>OUR VISITORS</h1>
            <img src="profile.jpg" alt="" class="img-responsive testimonialpic img-circle">

            <p>Learn about best of bests in the country <br>Learn about best of bests in the country<br>Learn about best of bests in the country<br>Learn about best of bests in the country</p>
          </div>
        </div>

    </div>
<script>
$(document).ready(function(){
  var owl = $('.owl-carousel');
                owl.owlCarousel({
                  loop: true,
                  nav: true,
                  margin: 10,
                  autoplay:true,
                  autoplayTimeout:4000,
                  autoplayHoverPause:true,
                  dots: false,
                  responsive: {
                    0: {
                      items: 1
                    },

                  }
                });
});
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </body>
</html>
