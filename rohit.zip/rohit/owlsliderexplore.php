<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>
    </title>
    <link rel="stylesheet" type="text/css" href="owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="owl.theme.default.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="owlstyle.css">
    <script src="jquery.min.js"></script>
    <script src="owl.carousel.min.js"></script>

  </head>
  <body>
    <div class="owl-carousel">
        <div class="item">
          <div class="text-center explorediv">
            <img src="medal.png" alt="" class="img-responsive colleges">
            <h4>FIND BEST COLLEGES</h4>
            <p>Learn about best of bests in the country</p>
          </div>
        </div>


        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>


        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>

        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>
        </div>
    </div>
<script>
$(document).ready(function(){
$(".owl-carousel").owlCarousel();
});
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </body>
</html>
