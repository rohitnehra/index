<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>
    <section>
      <div class="container">
        <div class="row">
          <!-- contact form -->
          <div class="col-sm-6 uscontact">
            <h2>Contact Us</h2>
            <div class="namob clearfix">
              <p>Name</p>
              <input type="text" name="" value="">
            </div>
            <div class="namob clearfix" id="mobile">
              <p>Mobile</p>
              <input type="text" name="" value="">
            </div>
            <div class="">
              <p>Email Address</p>
              <input type="email" name="" value="">
            </div>
            <div class="">
              <p>Message</p>
              <input type="text" name="" value="">
            </div>
            <div class="text-center">
              <button type="button" class="btn" name="button">Sumit</button>
            </div>
          </div>
          <!-- right block -->
          <div class="col-sm-6 rblock">
            <h4>Address</h4>
            <ul>
              <li> <span class="glyphicon glyphicon-envelope"></span>  Kothrud,Pune,Maharastra 11038</li>
              <li> <span class="glyphicon glyphicon-tags"></span>  919191919191</li>
              <li> <span class="glyphicon glyphicon-bookmark"></span>   info@info.com</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </body>
</html>
