<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="jquery.nicescroll.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style1.css">
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>
    <?php include 'header.php';?>
    <div class="container">
      <div class="row">
        <!-- filter section start -->
        <div class="col-sm-3">
        <h2>Refine Search</h2>
        <h3>State</h3>
        <div class="ourlists nicescroll-box">
          <ul class="wrap">
            <li><input type="checkbox" name="" value="">Maharastra</li>
            <li><input type="checkbox" name="" value="">Orrisa</li>
            <li><input type="checkbox" name="" value="">Goa</li>
            <li><input type="checkbox" name="" value="">Gugrat</li>
            <li><input type="checkbox" name="" value="">Rajasthan</li>
            <li><input type="checkbox" name="" value="">Delhi NCR</li>
            <li><input type="checkbox" name="" value="">Punjab</li>
            <li><input type="checkbox" name="" value="">Haryana</li>
            <li><input type="checkbox" name="" value="">Maharastra</li>
            <li><input type="checkbox" name="" value="">Orrisa</li>
            <li><input type="checkbox" name="" value="">Goa</li>
            <li><input type="checkbox" name="" value="">Gugrat</li>
            <li><input type="checkbox" name="" value="">Rajasthan</li>
            <li><input type="checkbox" name="" value="">Delhi NCR</li>
            <li><input type="checkbox" name="" value="">Punjab</li>
            <li><input type="checkbox" name="" value="">Haryana</li>
          </ul>
        </div>
        <h3>Course Level</h3>
        <div class="ourlists nicescroll-box">
          <ul class="wrap">
            <li><input type="checkbox" name="" value="">PG</li>
            <li><input type="checkbox" name="" value="">UG</li>
            <li><input type="checkbox" name="" value="">Diploma</li>
            <li><input type="checkbox" name="" value="">Doctoral</li>
          </ul>
        </div>
        <h3>Study Mode</h3>
        <div class="ourlists nicescroll-box">
          <ul class="wrap">
            <li><input type="checkbox" name="" value="">Full Time</li>
            <li><input type="checkbox" name="" value="">Part Time</li>
            <li><input type="checkbox" name="" value="">Distance</li>
            <li><input type="checkbox" name="" value="">Online</li>
          </ul>
        </div>
        <h3>Course Degree</h3>
        <div class="ourlists nicescroll-box">
          <ul class="wrap">
            <li><input type="checkbox" name="" value="">MBA</li>
            <li><input type="checkbox" name="" value="">BBA</li>
            <li><input type="checkbox" name="" value="">PGD</li>
            <li><input type="checkbox" name="" value="">BBM</li>
            <li><input type="checkbox" name="" value="">Other Masters</li>
            <li><input type="checkbox" name="" value="">Executive MBA</li>
            <li><input type="checkbox" name="" value="">MBA</li>
            <li><input type="checkbox" name="" value="">BBA</li>
            <li><input type="checkbox" name="" value="">PGD</li>
            <li><input type="checkbox" name="" value="">BBM</li>
            <li><input type="checkbox" name="" value="">Other Masters</li>
            <li><input type="checkbox" name="" value="">Executive MBA</li>
          </ul>
        </div>
        <h3>State</h3>
        <div class="ourlists nicescroll-box">
          <ul class="wrap">
            <li><input type="checkbox" name="" value="">Maharastra</li>
            <li><input type="checkbox" name="" value="">Orrisa</li>
            <li><input type="checkbox" name="" value="">Goa</li>
            <li><input type="checkbox" name="" value="">Gugrat</li>
            <li><input type="checkbox" name="" value="">Rajasthan</li>
            <li><input type="checkbox" name="" value="">Delhi NCR</li>
            <li><input type="checkbox" name="" value="">Punjab</li>
            <li><input type="checkbox" name="" value="">Haryana</li>
            <li><input type="checkbox" name="" value="">Maharastra</li>
            <li><input type="checkbox" name="" value="">Orrisa</li>
            <li><input type="checkbox" name="" value="">Goa</li>
            <li><input type="checkbox" name="" value="">Gugrat</li>
            <li><input type="checkbox" name="" value="">Rajasthan</li>
            <li><input type="checkbox" name="" value="">Delhi NCR</li>
            <li><input type="checkbox" name="" value="">Punjab</li>
            <li><input type="checkbox" name="" value="">Haryana</li>
          </ul>
        </div>
        </div>

      <div class="col-sm-9">
    <!-- college profie section -->
    <!-- aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa -->
    <div class="text-center" id="upperlabel">
      <h2>List of MBA Colleges in India</h2>
      <h4>6365 Colleges Found</h4>
      <hr>
    </div>

    <!-- aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa -->

      <!-- upper section start -->
        <div class="clearfix upperpro">
          <div class="image-box">
            <img src="loogoo.jpg" alt="" class="img-responsive">
          </div>
          <div class="image-cont">
            <p></p><button type="button" class="btn btn-success text-right">Follow</button>
            <h2>Indian Institute of Technology</h2>
            <ul>
              <li>Kanpur,Uttar Pradesh</li><li>Ownership:Government</li>
            </ul>
            <p>Rated (AAAA+) in Top MBA Colleges in Uttar Pradesh <span class="badge">?</span></p>
            <ul>
              <li>Approved by:UGC</li><li>Exams Accepted:CAT</li>
            </ul>
          </div>
        </div>
      <!-- upper section ends, middle section start-->
      <div class="">
        <div class="middlebox">
            <label>MBA</label><span class="badge">+2 more course</span>
        </div>
      </div>
      <!-- middel section ends, lower box start-->
      <div class="clearfix lowerbox">
        <ul>
          <li>Degree:MBA</li><li>Duration:2 Years</li><li>Mode:Full Time</li><li>Fee:2.91 Lakhs</li>
          <li id="compare"><input type="checkbox" name="" value="">Compare</li>
        </ul>
        <ul>

        </ul>

      </div>
      <!-- lower box ends -->
    <hr>
      <!-- 2nd college profile start -->
      <!-- upper section start -->
        <div class="clearfix upperpro">
          <div class="image-box">
            <img src="loogoo.jpg" alt="" class="img-responsive">
          </div>
          <div class="image-cont">
            <p></p><button type="button" class="btn btn-success text-right">Follow</button>
            <h2>Indian Institute of Technology</h2>
            <ul>
              <li>Kanpur,Uttar Pradesh</li><li>Ownership:Government</li>
            </ul>
            <p>Rated (AAAA+) in Top MBA Colleges in Uttar Pradesh <span class="badge">?</span></p>
            <ul>
              <li>Approved by:UGC</li><li>Exams Accepted:CAT</li>
            </ul>
          </div>
        </div>
      <!-- upper section ends, middle section start-->
      <div class="">
        <div class="middlebox">
            <label>MBA</label><span class="badge">+2 more course</span>
        </div>
      </div>
      <!-- middel section ends, lower box start-->
      <div class="clearfix lowerbox">
        <ul>
          <li>Degree:MBA</li><li>Duration:2 Years</li><li>Mode:Full Time</li><li>Fee:2.91 Lakhs</li>
          <li id="compare"><input type="checkbox" name="" value="">Compare</li>
        </ul>
        <ul>

        </ul>

      </div>
      <!-- lower box ends -->
      <hr>
      <!-- 2nd college profile end -->

      <!-- 2nd college profile start -->
      <!-- upper section start -->
        <div class="clearfix upperpro">
          <div class="image-box">
            <img src="loogoo.jpg" alt="" class="img-responsive">
          </div>
          <div class="image-cont">
            <p></p><button type="button" class="btn btn-success text-right">Follow</button>
            <h2>Indian Institute of Technology</h2>
            <ul>
              <li>Kanpur,Uttar Pradesh</li><li>Ownership:Government</li>
            </ul>
            <p>Rated (AAAA+) in Top MBA Colleges in Uttar Pradesh <span class="badge">?</span></p>
            <ul>
              <li>Approved by:UGC</li><li>Exams Accepted:CAT</li>
            </ul>
          </div>
        </div>
      <!-- upper section ends, middle section start-->
      <div class="">
        <div class="middlebox">
            <label>MBA</label><span class="badge">+2 more course</span>
        </div>
      </div>
      <!-- middel section ends, lower box start-->
      <div class="clearfix lowerbox">
        <ul>
          <li>Degree:MBA</li><li>Duration:2 Years</li><li>Mode:Full Time</li><li>Fee:2.91 Lakhs</li>
          <li id="compare"><input type="checkbox" name="" value="">Compare</li>
        </ul>
        <ul>

        </ul>

      </div>
      <!-- lower box ends -->
      <!-- 2nd college profile end -->
      <hr>
      <!-- 2nd college profile end -->

      <!-- 2nd college profile start -->
      <!-- upper section start -->
        <div class="clearfix upperpro">
          <div class="image-box">
            <img src="loogoo.jpg" alt="" class="img-responsive">
          </div>
          <div class="image-cont">
            <p></p><button type="button" class="btn btn-success text-right">Follow</button>
            <h2>Indian Institute of Technology</h2>
            <ul>
              <li>Kanpur,Uttar Pradesh</li><li>Ownership:Government</li>
            </ul>
            <p>Rated (AAAA+) in Top MBA Colleges in Uttar Pradesh <span class="badge">?</span></p>
            <ul>
              <li>Approved by:UGC</li><li>Exams Accepted:CAT</li>
            </ul>
          </div>
        </div>
      <!-- upper section ends, middle section start-->
      <div class="">
        <div class="middlebox">
            <label>MBA</label><span class="badge">+2 more course</span>
        </div>
      </div>
      <!-- middel section ends, lower box start-->
      <div class="clearfix lowerbox">
        <ul>
          <li>Degree:MBA</li><li>Duration:2 Years</li><li>Mode:Full Time</li><li>Fee:2.91 Lakhs</li>
          <li id="compare"><input type="checkbox" name="" value="">Compare</li>
        </ul>
        <ul>

        </ul>

      </div>
      <!-- lower box ends -->
      <!-- 2nd college profile end -->

      </div>
      </div>


    </div>




    <?php include 'footer.php';?>
  </body>
</html>
