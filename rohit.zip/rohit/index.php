<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css" href="owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="owl.theme.default.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="owlstyle.css">
    <script src="jquery.min.js"></script>
    <script src="owl.carousel.min.js"></script>
  </head>
  <body>

<?php include 'header.php';?>
<?php include 'carousel.php';?>
<?php include 'explore.php';?>
<?php include 'chooseyour.php';?>
<?php include 'testimonial.php';?>
<?php include 'courses.php';?>
<?php include 'colleges.php';?>
<?php include 'footer.php';?>
  </body>
</html>
