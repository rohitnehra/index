<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">

  </head>
  <body>
    <?php include 'header.php';?>
    <div id="examheader">
    <img src="img/bnr2.jpg" alt="" class="img-responsive">
  </div>

    <div class="container">
      <div class="row">

        <div class="text-center what-choose">
         <h1>DON'T KNOW WHAT TO CHOOSE ?<br>CHOOSE BY YOUR LEVEL</h1>
          <hr>
          <p>Collegedunia.com is an extensive search engine for the students, parents,<br>and education industry players who are seeking information</p>
        </div>

        <div class="col-md-4 text-center">
          <div class="after-10">
            <img src="img/after.jpg" class="img-responsive">
          <div class="after-title">
            <a href="#"><h4>AFTER 10TH COURSES</h4></a>
            <p>APPLICABLE FOR DIPLOMA COURSES & CERTIFICATION COURSES</p>
          </div>
          <div class="after-btn">
             <a href="#"><button class="btn btn-default btn-sm">12 Science</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 Arts</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Commerce</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Computer Application</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 ITI</button></a>
          </div>
        </div>
        </div>

        <div class="col-md-4 text-center">
          <div class="after-10">
            <img src="img/after.jpg" class="img-responsive">
          <div class="after-title">
            <a href="#"><h4>AFTER 10TH COURSES</h4></a>
            <p>APPLICABLE FOR DIPLOMA COURSES & CERTIFICATION COURSES</p>
          </div>
          <div class="after-btn">
             <a href="#"><button class="btn btn-default btn-sm">12 Science</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 Arts</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Commerce</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Computer Application</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 ITI</button></a>
          </div>
        </div>
        </div>

        <div class="col-md-4 text-center">
          <div class="after-10">
            <img src="img/after.jpg" class="img-responsive">
          <div class="after-title">
            <a href="#"><h4>AFTER 10TH COURSES</h4></a>
            <p>APPLICABLE FOR DIPLOMA COURSES & CERTIFICATION COURSES</p>
          </div>
          <div class="after-btn">
            <a href="#"><button class="btn btn-default btn-sm">12 Science</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 Arts</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Commerce</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Computer Application</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 ITI</button></a>
          </div>
        </div>
        </div>
        <!--sec 2-->
        <div class="col-md-4 text-center">
          <div class="after-10">
            <img src="img/after.jpg" class="img-responsive">
          <div class="after-title">
            <a href="#"><h4>AFTER 10TH COURSES</h4></a>
            <p>APPLICABLE FOR DIPLOMA COURSES & CERTIFICATION COURSES</p>
          </div>
          <div class="after-btn">
             <a href="#"><button class="btn btn-default btn-sm">12 Science</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 Arts</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Commerce</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Computer Application</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 ITI</button></a>
          </div>
        </div>
        </div>

        <div class="col-md-4 text-center">
          <div class="after-10">
            <img src="img/after.jpg" class="img-responsive">
          <div class="after-title">
            <a href="#"><h4>AFTER 10TH COURSES</h4></a>
            <p>APPLICABLE FOR DIPLOMA COURSES & CERTIFICATION COURSES</p>
          </div>
          <div class="after-btn">
             <a href="#"><button class="btn btn-default btn-sm">12 Science</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 Arts</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Commerce</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Computer Application</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 ITI</button></a>
          </div>
        </div>
        </div>

        <div class="col-md-4 text-center">
          <div class="after-10">
            <img src="img/after.jpg" class="img-responsive">
          <div class="after-title">
            <a href="#"><h4>AFTER 10TH COURSES</h4></a>
            <p>APPLICABLE FOR DIPLOMA COURSES & CERTIFICATION COURSES</p>
          </div>
          <div class="after-btn">
            <a href="#"><button class="btn btn-default btn-sm">12 Science</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 Arts</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Commerce</button></a>
            <a href="#"><button class="btn btn-default btn-sm">1 Computer Application</button></a>
            <a href="#"><button class="btn btn-default btn-sm">3 ITI</button></a>
          </div>
        </div>
        </div>

      </div>
    </div>

<!--choose interest by sec-->
<section class="choose-interest">
  <div class="container">
      <div class="row">
        <div class="text-center">
         <h1>CHOOSE INTEREST BY</h1>
          <span class="interest-hr"><hr></span>
          <p>Collegedunia.com is an extensive search engine for the students, parents,<br>and education industry players who are seeking information</p>
        </div>
      </div>

    <div class="col-md-3">
        <div class="interest-box text-center">
          <p><span class="glyphicon glyphicon-user">&nbsp;</span><a href="#">ENGINEERING</a></p>
          <hr>
          <a href="#">BAMS</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">B.SC (MEDICINE)</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">BHMS</a>

          <div class="box-btn">
            <a href="#"><button class="btn btn-default btn-sm">Explore all course</button></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="interest-box text-center">
          <p><span class="glyphicon glyphicon-user">&nbsp;</span><a href="#">ENGINEERING</a></p>
          <hr>
          <a href="#">BAMS</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">B.SC (MEDICINE)</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">BHMS</a>

          <div class="box-btn">
            <a href="#"><button class="btn btn-default btn-sm">Explore all course</button></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="interest-box text-center">
          <p><span class="glyphicon glyphicon-user">&nbsp;</span><a href="#">ENGINEERING</a></p>
          <hr>
          <a href="#">BAMS</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">B.SC (MEDICINE)</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">BHMS</a>

          <div class="box-btn">
            <a href="#"><button class="btn btn-default btn-sm">Explore all course</button></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="interest-box text-center">
          <p><span class="glyphicon glyphicon-user">&nbsp;</span><a href="#">ENGINEERING</a></p>
          <hr>
          <a href="#">BAMS</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">B.SC (MEDICINE)</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">BHMS</a>

          <div class="box-btn">
            <a href="#"><button class="btn btn-default btn-sm">Explore all course</button></a>
          </div>
        </div>
      </div>
      <!--sec2-->
      <div class="col-md-3">
        <div class="interest-box text-center">
          <p><span class="glyphicon glyphicon-user">&nbsp;</span><a href="#">ENGINEERING</a></p>
          <hr>
          <a href="#">BAMS</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">B.SC (MEDICINE)</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">BHMS</a>

          <div class="box-btn">
            <a href="#"><button class="btn btn-default btn-sm">Explore all course</button></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="interest-box text-center">
          <p><span class="glyphicon glyphicon-user">&nbsp;</span><a href="#">ENGINEERING</a></p>
          <hr>
          <a href="#">BAMS</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">B.SC (MEDICINE)</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">BHMS</a>

          <div class="box-btn">
            <a href="#"><button class="btn btn-default btn-sm">Explore all course</button></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="interest-box text-center">
          <p><span class="glyphicon glyphicon-user">&nbsp;</span><a href="#">ENGINEERING</a></p>
          <hr>
          <a href="#">BAMS</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">B.SC (MEDICINE)</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">BHMS</a>

          <div class="box-btn">
            <a href="#"><button class="btn btn-default btn-sm">Explore all course</button></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="interest-box text-center">
          <p><span class="glyphicon glyphicon-user">&nbsp;</span><a href="#">ENGINEERING</a></p>
          <hr>
          <a href="#">BAMS</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">B.SC (MEDICINE)</a>&nbsp;&nbsp;I&nbsp;&nbsp;<a href="#">BHMS</a>

          <div class="box-btn">
            <a href="#"><button class="btn btn-default btn-sm">Explore all course</button></a>
          </div>
        </div>
      </div>

    </div>
</section>
<?php include 'footer.php';?>
<script>
  $(function(){
  $(".dropdown").hover(
          function() {
              $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
              $(this).toggleClass('open');
              $('b', this).toggleClass("caret caret-up");
          },
          function() {
              $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
              $(this).toggleClass('open');
              $('b', this).toggleClass("caret caret-up");
          });
  });

</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="bootstrap.min.js"></script>
  </body>
</html>
