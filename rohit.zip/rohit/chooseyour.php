<div class="container"><!--CHOOSE YOUR FUTURE-->
  <div class="row">
<div class="college-sec text-center">
  <h1>CHOOSE YOUR FUTURE</h1>
  <hr>
  <p>Collegedunia.com is an extensive search engine for the students, parents,<br>and education industry players who are seeking information</p>

  <div class="college-btn">
    <p><a href="#"><button class="btn btn-default">COLLEGES</button></a>&nbsp;<a href="#"><button class="btn btn-default">EXAMS</button></a></p>
  </div>
</div>
</div>
</div>
  <div class="container"><!--sec1-->
    <div class="row">
      <div class="col-md-3">
        <div class="your-future text-center">
          <a href="#"><img src="img/college.png">
          <h4>MANAGEMENT</h4></a>
        <p>473 COLLEGES</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="your-future text-center">
          <a href="#"><img src="img/college.png">
          <h4>MANAGEMENT</h4></a>
        <p>473 COLLEGES</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="your-future text-center">
          <a href="#"><img src="img/college.png">
          <h4>MANAGEMENT</h4></a>
        <p>473 COLLEGES</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="your-future text-center">
          <a href="#"><img src="img/college.png">
          <h4>MANAGEMENT</h4></a>
        <p>473 COLLEGES</p>
        </div>
      </div>
      <!--sec 2-->
      <div class="col-md-3">
        <div class="your-future text-center">
          <a href="#"><img src="img/college.png">
          <h4>MANAGEMENT</h4></a>
        <p>473 COLLEGES</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="your-future text-center">
          <a href="#"><img src="img/college.png">
          <h4>MANAGEMENT</h4></a>
        <p>473 COLLEGES</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="your-future text-center">
          <a href="#"><img src="img/college.png">
          <h4>MANAGEMENT</h4></a>
        <p>473 COLLEGES</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="your-future text-center">
          <img src="img/college.png">
          <h4>MANAGEMENT</h4>
        <p>473 COLLEGES</p>
        </div>
      </div>
    </div>
  </div>
