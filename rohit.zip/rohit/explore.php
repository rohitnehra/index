<div class="container"><!-- slide section title-->
  <div class="row">
  <div class="text-center explore">
    <h1>EXPLORE ALMOST EVERYTHING</h1>
    <hr>
    <p>Collegedunia.com is an extensive search engine for the students, parents,<br>and education industry players who are seeking information</p>
  </div>
</div>
</div>

<!-- slide section -->
<div class="owl-carousel owl-bg owl-theme">
        <div class="item">
          <div class="text-center explorediv">
            <img src="medal.png" alt="" class="img-responsive colleges">
            <h4>FIND BEST COLLEGES</h4>
            <p>Learn about best of bests in the country</p>
          </div>
        </div>



          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>




          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>


          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
        </div>

          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
        </div>

          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>


          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>


          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>


          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>


          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>


          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>


          <div class="item">
            <div class="text-center explorediv">
              <img src="medal.png" alt="" class="img-responsive colleges">
              <h4>FIND BEST COLLEGES</h4>
              <p>Learn about best of bests in the country</p>
            </div>
          </div>

    </div>
