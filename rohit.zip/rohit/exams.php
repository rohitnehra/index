<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">

  </head>
  <body>
    <?php include 'header.php';?>

    <div id="examheader">
  <img src="img/bnr3.jpg" alt="" class="img-responsive">
</div>

<section class="exams-page">
<div class="container"><!-- Top Courses section-->
  <div class="row">
    <div class="exams-title text-center">
      <h1>Explore by Category</h1>
      <hr>
      <h5>BROWSE 100+ ENTRANCE EXAMS</h5>
    </div>

      <div class="col-md-6"><!--first sec-->
        <div class="entrance-exam">
          <div class="icon-title clearfix">
        <div class="left-icon">
          <p><span class="glyphicon glyphicon-user"></span></p>
        </div>
        <div class="right-title">
          <a href="#"><h3>ENGINEERING</h3></a>
        </div>
      </div>
      <a href="#"><p>SUAT - Sharda University Admission Test</p></a>
      <a href="#"><p>GRE - Graduate Record Examination</p></a>
      <a href="#"><p>BPTPIA CET - Bihar Private Technical & Professional Institutions Association Competitive Entrance Test</p></a>
      <a href="#"><p>GLAET - GLA University Entrance Test</p></a>
      <a href="#"><p>HPCET - Himachal Pradesh Common Entrance Test</p></a>
      <a href="#"><button class="btn btn-default">BE/B.Tech (100)</button></a>
      <a href="#"><button class="btn btn-default">ME/M.Tech (46)</button></a>
    </div>
  </div>

  <div class="col-md-6"><!--first sec-->
        <div class="entrance-exam">
          <div class="icon-title clearfix">
        <div class="left-icon">
          <p><span class="glyphicon glyphicon-user"></span></p>
        </div>
        <div class="right-title">
          <a href="#"><h3>ENGINEERING</h3></a>
        </div>
      </div>
      <a href="#"><p>SUAT - Sharda University Admission Test</p></a>
      <a href="#"><p>GRE - Graduate Record Examination</p></a>
      <a href="#"><p>BPTPIA CET - Bihar Private Technical & Professional Institutions Association Competitive Entrance Test</p></a>
      <a href="#"><p>GLAET - GLA University Entrance Test</p></a>
      <a href="#"><p>HPCET - Himachal Pradesh Common Entrance Test</p></a>
      <a href="#"><button class="btn btn-default">BE/B.Tech (100)</button></a>
      <a href="#"><button class="btn btn-default">ME/M.Tech (46)</button></a>
    </div>
  </div>

  <div class="exam-sec2">
   <div class="col-md-6"><!--first sec-->
        <div class="entrance-exam">
          <div class="icon-title clearfix">
        <div class="left-icon">
          <p><span class="glyphicon glyphicon-user"></span></p>
        </div>
        <div class="right-title">
          <a href="#"><h3>ENGINEERING</h3></a>
        </div>
      </div>
      <a href="#"><p>SUAT - Sharda University Admission Test</p></a>
      <a href="#"><p>GRE - Graduate Record Examination</p></a>
      <a href="#"><p>BPTPIA CET - Bihar Private Technical & Professional Institutions Association Competitive Entrance Test</p></a>
      <a href="#"><p>GLAET - GLA University Entrance Test</p></a>
      <a href="#"><p>HPCET - Himachal Pradesh Common Entrance Test</p></a>
      <a href="#"><button class="btn btn-default">BE/B.Tech (100)</button></a>
      <a href="#"><button class="btn btn-default">ME/M.Tech (46)</button></a>
    </div>
  </div>

  <div class="col-md-6"><!--first sec-->
        <div class="entrance-exam">
          <div class="icon-title clearfix">
        <div class="left-icon">
          <p><span class="glyphicon glyphicon-user"></span></p>
        </div>
        <div class="right-title">
          <a href="#"><h3>ENGINEERING</h3></a>
        </div>
      </div>
      <a href="#"><p>SUAT - Sharda University Admission Test</p></a>
      <a href="#"><p>GRE - Graduate Record Examination</p></a>
      <a href="#"><p>BPTPIA CET - Bihar Private Technical & Professional Institutions Association Competitive Entrance Test</p></a>
      <a href="#"><p>GLAET - GLA University Entrance Test</p></a>
      <a href="#"><p>HPCET - Himachal Pradesh Common Entrance Test</p></a>
      <a href="#"><button class="btn btn-default">BE/B.Tech (100)</button></a>
      <a href="#"><button class="btn btn-default">ME/M.Tech (46)</button></a>
    </div>
  </div>
</div>

<div class="exam-sec2">
   <div class="col-md-6"><!--first sec-->
        <div class="entrance-exam">
          <div class="icon-title clearfix">
        <div class="left-icon">
          <p><span class="glyphicon glyphicon-user"></span></p>
        </div>
        <div class="right-title">
          <a href="#"><h3>ENGINEERING</h3></a>
        </div>
      </div>
      <a href="#"><p>SUAT - Sharda University Admission Test</p></a>
      <a href="#"><p>GRE - Graduate Record Examination</p></a>
      <a href="#"><p>BPTPIA CET - Bihar Private Technical & Professional Institutions Association Competitive Entrance Test</p></a>
      <a href="#"><p>GLAET - GLA University Entrance Test</p></a>
      <a href="#"><p>HPCET - Himachal Pradesh Common Entrance Test</p></a>
      <a href="#"><button class="btn btn-default">BE/B.Tech (100)</button></a>
      <a href="#"><button class="btn btn-default">ME/M.Tech (46)</button></a>
    </div>
  </div>

  <div class="col-md-6"><!--first sec-->
        <div class="entrance-exam">
          <div class="icon-title clearfix">
        <div class="left-icon">
          <p><span class="glyphicon glyphicon-user"></span></p>
        </div>
        <div class="right-title">
          <a href="#"><h3>ENGINEERING</h3></a>
        </div>
      </div>
      <a href="#"><p>SUAT - Sharda University Admission Test</p></a>
      <a href="#"><p>GRE - Graduate Record Examination</p></a>
      <a href="#"><p>BPTPIA CET - Bihar Private Technical & Professional Institutions Association Competitive Entrance Test</p></a>
      <a href="#"><p>GLAET - GLA University Entrance Test</p></a>
      <a href="#"><p>HPCET - Himachal Pradesh Common Entrance Test</p></a>
      <a href="#"><button class="btn btn-default">BE/B.Tech (100)</button></a>
      <a href="#"><button class="btn btn-default">ME/M.Tech (46)</button></a>
    </div>
  </div>
</div>

</div><!-- row-->
</div><!--container-->
</section>










    <?php include 'footer.php';?>
  </body>
</html>
