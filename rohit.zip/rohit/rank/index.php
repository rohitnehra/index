<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../style.css">
  <body>
    <?php include '../header.php';?>
    <div class="container-fluid rankall">
      <div class="text-center">
        <h2>CHOOSE EXAM</h2>
      </div>
      <div class="row">
        <div class="col-sm-3 text-center rankexam">
          <a href="#">
            <img src="iit.jpg" class="img-thumbnail img-responsive" alt="IIT">
            <p>IIT JEE</p>
          </a>

        </div>
        <div class="col-sm-3 text-center rankexam">
          <a href="#">
            <img src="iit.jpg" class="img-thumbnail img-responsive" alt="IIT">
            <p>IIT JEE</p>
          </a>

        </div>
        <div class="col-sm-3 text-center rankexam">
          <a href="#">
            <img src="iit.jpg" class="img-thumbnail img-responsive" alt="IIT">
            <p>IIT JEE</p>
          </a>

        </div>
        <div class="col-sm-3 text-center rankexam">
          <a href="#">
            <img src="iit.jpg" class="img-thumbnail img-responsive" alt="IIT">
            <p>IIT JEE</p>
          </a>

        </div>
        <div class="col-sm-3 text-center rankexam">
          <a href="#">
            <img src="iit.jpg" class="img-thumbnail img-responsive" alt="IIT">
            <p>IIT JEE</p>
          </a>

        </div>
        <div class="col-sm-3 text-center rankexam">
          <a href="#">
            <img src="iit.jpg" class="img-thumbnail img-responsive" alt="IIT">
            <p>IIT JEE</p>
          </a>

        </div>
        <div class="col-sm-3 text-center rankexam">
          <a href="#">
            <img src="iit.jpg" class="img-thumbnail img-responsive" alt="IIT">
            <p>IIT JEE</p>
          </a>

        </div>
        <div class="col-sm-3 text-center rankexam">
          <a href="#">
            <img src="iit.jpg" class="img-thumbnail img-responsive" alt="IIT">
            <p>IIT JEE</p>
          </a>

        </div>
      </div>
      <hr>
      <div class="container">
        <div class="text-center">
          <h2>Predict Your Rank</h2>
        </div>
        <div class="row text-center rankbottom">
          <div class="col-sm-4">
            <h3>Step 1</h3>
            <img src="select.png" class="img-responsive" alt="">
            <h3>Choose Your Exam</h3>
          </div>
          <div class="col-sm-4">
            <h3>Step 2</h3>
            <img src="list.png" class="img-responsive" alt="">
            <h3>Enter Details</h3>
          </div>
          <div class="col-sm-4">
            <h3>Predicted Rank</h3>
            <img src="like.png" class="img-responsive" alt="">
            <h3>Choose Your Exam</h3>
          </div>
        </div>





      </div>
<hr>
    </div>
    <?php include '../footer.php';?>
  </body>
</html>
