<div class="bg-color">
<div class="container bottom-space"><!-- TOP FEATURED COLLEGES OF INDIA-->
  <div class="row">
    <div class="college-india text-center">
      <h1>TOP FEATURED COLLEGES OF INDIA</h1>
      <hr>
      <p>Collegedunia.com is an extensive search engine for the students, parents,<br>and education industry players who are seeking information</p>
    </div>
      <div class="col-md-3"><!--first sec-->
        <div class="featured-college">
        <img src="img/img1.jpg" class="img-responsive">
        <div class="below-text2 clearfix">
        <div class="left-badge">
          <p class="badge">9.9</p>
        </div>
        <div class="right-text">
          <a href="#"><p>M.Phil/Ph.D in Engineering</p></a>
        </div>
    </div>
    <a href="#"><h5>VIEW ALL COURSES & FEES</h5></a>
  </div>
</div>

      <div class="col-md-3"><!--2 sec-->
        <div class="featured-college">
        <img src="img/img1.jpg" class="img-responsive">
        <div class="below-text2 clearfix">
        <div class="left-badge">
          <p class="badge">9.9</p>
        </div>
        <div class="right-text">
          <a href="#"><p>M.Phil/Ph.D in Engineering</p></a>
        </div>
      </div>
      <a href="#"><h5>VIEW ALL COURSES & FEES</h5></a>
    </div>
  </div>

  <div class="col-md-3"><!--3 sec-->
        <div class="featured-college">
        <img src="img/img1.jpg" class="img-responsive">
        <div class="below-text2 clearfix">
        <div class="left-badge">
          <p class="badge">9.9</p>
        </div>
        <div class="right-text">
          <a href="#"><p>M.Phil/Ph.D in Engineering</p></a>
        </div>
      </div>
      <a href="#"><h5>VIEW ALL COURSES & FEES</h5></a>
    </div>
  </div>

  <div class="col-md-3"><!--4 sec-->
        <div class="featured-college">
        <img src="img/img1.jpg" class="img-responsive">
        <div class="below-text2 clearfix">
        <div class="left-badge">
          <p class="badge">9.9</p>
        </div>
        <div class="right-text">
          <a href="#"><p>M.Phil/Ph.D in Engineering</p></a>
        </div>
      </div>
      <a href="#"><h5>VIEW ALL COURSES & FEES</h5></a>
    </div>
  </div>

  </div>
</div>
</div>
